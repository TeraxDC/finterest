# Finterest
a simple example nodejs and mongodb app based on Pinterest.

![](docs/screenshot.png)

https://www.it-swarm.dev/es/mongodb/busqueda-de-texto-parcial-y-completo-de-mongodb/833605141/